﻿namespace WindowsFormsApp4
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.conPassTextBox = new System.Windows.Forms.TextBox();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.conEmTextBox = new System.Windows.Forms.TextBox();
            this.emTextBox = new System.Windows.Forms.TextBox();
            this.userNameBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.conPassLabel = new System.Windows.Forms.Label();
            this.passLabel = new System.Windows.Forms.Label();
            this.conEmLabel = new System.Windows.Forms.Label();
            this.emLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.userName = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.passLab = new System.Windows.Forms.Label();
            this.useNameLab = new System.Windows.Forms.Label();
            this.createButton = new System.Windows.Forms.Button();
            this.loginButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // conPassTextBox
            // 
            this.conPassTextBox.Location = new System.Drawing.Point(243, 151);
            this.conPassTextBox.Name = "conPassTextBox";
            this.conPassTextBox.Size = new System.Drawing.Size(221, 20);
            this.conPassTextBox.TabIndex = 37;
            // 
            // passTextBox
            // 
            this.passTextBox.Location = new System.Drawing.Point(243, 122);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.Size = new System.Drawing.Size(221, 20);
            this.passTextBox.TabIndex = 36;
            // 
            // conEmTextBox
            // 
            this.conEmTextBox.Location = new System.Drawing.Point(243, 85);
            this.conEmTextBox.Name = "conEmTextBox";
            this.conEmTextBox.Size = new System.Drawing.Size(221, 20);
            this.conEmTextBox.TabIndex = 35;
            // 
            // emTextBox
            // 
            this.emTextBox.Location = new System.Drawing.Point(243, 52);
            this.emTextBox.Name = "emTextBox";
            this.emTextBox.Size = new System.Drawing.Size(221, 20);
            this.emTextBox.TabIndex = 34;
            // 
            // userNameBox
            // 
            this.userNameBox.Location = new System.Drawing.Point(243, 14);
            this.userNameBox.Name = "userNameBox";
            this.userNameBox.Size = new System.Drawing.Size(221, 20);
            this.userNameBox.TabIndex = 33;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(146, 202);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(267, 53);
            this.button1.TabIndex = 32;
            this.button1.Text = "Create Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // conPassLabel
            // 
            this.conPassLabel.AutoSize = true;
            this.conPassLabel.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conPassLabel.Location = new System.Drawing.Point(31, 142);
            this.conPassLabel.Name = "conPassLabel";
            this.conPassLabel.Size = new System.Drawing.Size(177, 33);
            this.conPassLabel.TabIndex = 31;
            this.conPassLabel.Text = "Confirm Password:";
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passLabel.Location = new System.Drawing.Point(31, 109);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(102, 33);
            this.passLabel.TabIndex = 30;
            this.passLabel.Text = "Password:";
            // 
            // conEmLabel
            // 
            this.conEmLabel.AutoSize = true;
            this.conEmLabel.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conEmLabel.Location = new System.Drawing.Point(31, 76);
            this.conEmLabel.Name = "conEmLabel";
            this.conEmLabel.Size = new System.Drawing.Size(141, 33);
            this.conEmLabel.TabIndex = 29;
            this.conEmLabel.Text = "Confirm Email:";
            // 
            // emLabel
            // 
            this.emLabel.AutoSize = true;
            this.emLabel.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emLabel.Location = new System.Drawing.Point(31, 43);
            this.emLabel.Name = "emLabel";
            this.emLabel.Size = new System.Drawing.Size(72, 33);
            this.emLabel.TabIndex = 28;
            this.emLabel.Text = "Email: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(67, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 27;
            // 
            // userName
            // 
            this.userName.AutoSize = true;
            this.userName.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.Location = new System.Drawing.Point(31, 10);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(204, 33);
            this.userName.TabIndex = 26;
            this.userName.Text = "User Name (Optional):";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.passLab);
            this.panel1.Controls.Add(this.useNameLab);
            this.panel1.Controls.Add(this.createButton);
            this.panel1.Controls.Add(this.loginButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(495, 265);
            this.panel1.TabIndex = 38;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(148, 98);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(218, 20);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(145, 36);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(221, 20);
            this.textBox7.TabIndex = 11;
            // 
            // passLab
            // 
            this.passLab.AutoSize = true;
            this.passLab.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passLab.Location = new System.Drawing.Point(34, 89);
            this.passLab.Name = "passLab";
            this.passLab.Size = new System.Drawing.Size(108, 33);
            this.passLab.TabIndex = 10;
            this.passLab.Text = "Password: ";
            // 
            // useNameLab
            // 
            this.useNameLab.AutoSize = true;
            this.useNameLab.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useNameLab.Location = new System.Drawing.Point(34, 27);
            this.useNameLab.Name = "useNameLab";
            this.useNameLab.Size = new System.Drawing.Size(118, 33);
            this.useNameLab.TabIndex = 9;
            this.useNameLab.Text = "User Name: ";
            // 
            // createButton
            // 
            this.createButton.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createButton.Location = new System.Drawing.Point(254, 191);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(186, 44);
            this.createButton.TabIndex = 8;
            this.createButton.Text = "Create Account ";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // loginButton
            // 
            this.loginButton.Font = new System.Drawing.Font("Times New Roman Uni", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginButton.Location = new System.Drawing.Point(40, 191);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(167, 45);
            this.loginButton.TabIndex = 7;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 265);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.conPassTextBox);
            this.Controls.Add(this.passTextBox);
            this.Controls.Add(this.conEmTextBox);
            this.Controls.Add(this.emTextBox);
            this.Controls.Add(this.userNameBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.conPassLabel);
            this.Controls.Add(this.passLabel);
            this.Controls.Add(this.conEmLabel);
            this.Controls.Add(this.emLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.userName);
            this.Name = "Login";
            this.Text = "Login";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox conPassTextBox;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.TextBox conEmTextBox;
        private System.Windows.Forms.TextBox emTextBox;
        private System.Windows.Forms.TextBox userNameBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label conPassLabel;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.Label conEmLabel;
        private System.Windows.Forms.Label emLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label userName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label passLab;
        private System.Windows.Forms.Label useNameLab;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Button loginButton;
    }
}

