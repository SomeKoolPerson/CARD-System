﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class Collection
    {
        private List<Item> _collection;
        private double _totalValue;

        public Collection()
        {
            _collection = new List<Item>();
        }

        public Collection(Collection col) { _collection = col.getCollection(); }

        public List<Item> getCollection() { return _collection; }
        // returns the Item object associated with the given name
        public Item getItem(String name)
        {
            Item toReturn = null;
            foreach (Item item in _collection)
            {
                if (item.getName().Equals(name))
                {
                    toReturn = item;
                }
                break;
            }
            return toReturn;
        }
        public void AddItem(Item item) { _collection.Add(item); }
        public void RemoveItem(Item item)
        {
            foreach (Item eachitem in _collection)
            {
                if (item.getName().Equals(eachitem.getName()))
                {
                    _collection.Remove(eachitem);
                }
                break;
            }
        }
        public void RemoveItems(Item item)
        {
            foreach (Item eachitem in _collection)
            {
                if (item.getName().Equals(eachitem.getName()))
                {
                    _collection.Remove(eachitem);
                }
            }
        }
        public void calcTotalValue()
        {
            foreach (Item eachitemm in _collection)
            {
                _totalValue += eachitemm.getPrice();
            }
        }
    }
}
