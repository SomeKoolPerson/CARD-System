﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Login : Form
    {
        List<User> database = new List<User>();

        private String _username;
        private String _email;
        private String _password;

        public Login()
        {
            // for simulating a database
            for (int i = 0; i < 20; i++)
            {
                User newUser = new User("User " + i, "2000000" + i, "Number_" + i + "@CARD.com");
                database.Add(newUser);
            }
            foreach (User user in database)
            {
                Collection collection = new Collection();
                for (int i=0;i<30;i++)
                {
                    Item item = new Item("Item " + i, "The Best", "New", "Magic: The Gaterning Card", (i*0.20));
                    collection.AddItem(item);
                }
                user.setCollection(collection);
            }
            InitializeComponent();
        }

        private void userName_Click(object sender, EventArgs e)
        {

        }

        private void userBox_TextChanged(object sender, EventArgs e)
        {

        }

        // returns true if we can 1.) find the user by either name or email in the database and 2.) the inputted password
        // matches that in the database
        private bool validateUser()
        {
            bool isValidUser = false;

            // Do something here to find the user in the database and fetch the missing information (uername or email)
            // If username or email can't be found in database, set the appropriate value to empty string

            if (userBox.Text.Contains("@"))
            {
                _email = userBox.Text;
                _username = "";
            } else
            {
                _username = userBox.Text;
                _email = "";
            }
            _password = textBox1.Text;

            bool hasAllInfo = (!_email.Equals("") || !_username.Equals("")) && !_password.Equals("");

            if (hasAllInfo)
            {
                foreach (User user in database)
                {
                    bool hasUsername = !_username.Equals("");
                    if (hasUsername)
                    {
                        isValidUser = user.getUsername().Equals(_username) && user.getPassword().Equals(_password);
                        if (isValidUser)
                        {
                            break;
                        }
                    }
                    else
                    {
                        isValidUser = user.getEmail().Equals(_email) && user.getPassword().Equals(_password);
                        if (isValidUser)
                        {
                            break;
                        }
                    }
                }
            }
            

            return isValidUser;
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            if (validateUser())
            {
                Verify verify = new Verify(userBox.Text, textBox1.Text, userBox.Text + "@CARD.com", this, database);
                verify.Show();
                this.Hide();
            }
            else
            {
                label1.Visible = true;
                label1.Enabled = true;
            }
        }

        public void clear()
        {
            userBox.Clear();
            textBox1.Clear();
        }

        private void passwordLabel_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Enabled = false;
            label1.Visible = false;
        }
    }
}
